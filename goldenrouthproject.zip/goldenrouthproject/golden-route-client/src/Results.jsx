import React from 'react';
function Results({ nearestPlane, closureTime, noThreat, error, calculated, onSave }) {
  if (error) return <p style={{ color: 'red' }}>⚠️ שגיאה: {error}</p>;
  if (!calculated) return <p>הזן נתונים לחישוב.</p>;
  if (noThreat) return <p>✅ אין איום בטווח.</p>;
  return (
    <div className="results-card" style={{ border: '1px solid #ccc', padding: '15px', borderRadius: '8px' }}>
      <h3>⚠️ התראת איום </h3>
      <p><strong>מזהה מטוס:</strong> {nearestPlane.id}</p>
      <p><strong>מדינה:</strong> {nearestPlane.country || "לא ידוע"}</p>
      <p><strong>גובה:</strong> {nearestPlane.altitude} רגל</p>
      <p><strong>מרחק:</strong> {nearestPlane.distance?.toFixed(2)} ק"מ</p>
      <hr />
      <p><strong>מהירות מטוס:</strong> {nearestPlane.velocity?.toFixed(0)} קמ"ש</p>
      <p><strong>כיוון טיסה:</strong> {nearestPlane.heading?.toFixed(0)}°</p>
      <p style={{ color: 'red', fontSize: '1.2em' }}>
        <strong>זמן סגירה משוקלל:</strong> {closureTime ? `${closureTime.toFixed(2)} שעות` : "לא ניתן לחישוב"}
      </p>
      <button onClick={onSave} style={{ cursor: 'pointer', marginTop: '10px' }}>שמור מבצע</button>
    </div>
  );
}
export default Results;