const express = require('express');
const { PrismaClient } = require('@prisma/client');
const cors = require('cors');
const { getDistance, getGreatCircleBearing } = require('geolib');

const app = express();
const prisma = new PrismaClient();
const PORT = 4000;

// הגדרות בסיסיות לשרת: מאפשר תקשורת עם ה-Frontend וקריאת נתוני JSON
app.use(cors());
app.use(express.json());

// פנייה ל API OpenSky
async function fetchFlightData() {
    try {
        const response = await fetch('https://opensky-network.org/api/states/all');
        
        if (response.ok === false) {
            throw new Error("שגיאה בקבלת נתונים מ-OpenSky");
        }
        
        const data = await response.json();
        const allStates = data.states; // ה-API מחזיר רשימה בשם states
        
        // אם יש נתונים נחזיר אותם, אם לא נחזיר מערך ריק כדי שהקוד לא יקרוס
        if (allStates) {
            return allStates;
        } else {
            return [];
        }
    } catch (error) {
        console.log("בעיה בפנייה לשרת החיצוני:", error);
        throw error;
    }
}

// אלגוריתם סעיף ה': חישוב מסלול עוקף מכשולים
// הפונקציה בודקת אם הקו הישר בין המטוס לנכס עובר בתוך מעגל ההגנה
function calculatePathAvoidingZone(p1, p2, zoneCenter, zoneRadius) {
    const dist1 = getDistance(p1, zoneCenter) / 1000; // מרחק שהזנת מהמכשול
    const dist2 = getDistance(p2, zoneCenter) / 1000; // מרחק המטוס מהמכשול
    const directDist = getDistance(p1, p2) / 1000;   // המרחק הישיר בקו אווירי

    // אם אחד הצדדים כבר בתוך המעגל לא לחשב מעקף
    if (dist1 <= zoneRadius || dist2 <= zoneRadius || zoneRadius <= 0) {
        return directDist;
    }

    try {
        // מציאת זווית המשיק (Tangent) למעגל
        const angle1 = Math.acos(zoneRadius / dist1);
        const angle2 = Math.acos(zoneRadius / dist2);
        
        // חישוב הזווית הכוללת בין המטוס לנקודות שהזנת ביחס למרכז המעגל (לפי משפט הקוסינוסים)
        let cosTotal = (dist1 * dist1 + dist2 * dist2 - directDist * directDist) / (2 * dist1 * dist2);
        
        // הגנה על החישוב שלא יחרוג מהטווח של acos
        if (cosTotal > 1) cosTotal = 1;
        if (cosTotal < -1) cosTotal = -1;
        
        const totalAngle = Math.acos(cosTotal);
        
        // חישוב הזווית של הקשת שצריך לעבור כדי לעקוף את המכשול
        const arcAngle = totalAngle - angle1 - angle2;

        // אם הזווית חיובית, סימן שהמסלול הישיר חסום וצריך לעקוף
        if (arcAngle > 0) {
            // חישוב אורך שני המשיקים (פיתגורס)
            const side1 = Math.sqrt(dist1 * dist1 - zoneRadius * zoneRadius);
            const side2 = Math.sqrt(dist2 * dist2 - zoneRadius * zoneRadius);
            // אורך הקשת לפי רדיוס וזווית
            const arcLength = zoneRadius * arcAngle;
            
            // המרחק החדש הוא סכום המשיקים והקשת
            return side1 + side2 + arcLength; 
        }
    } catch (e) {
        return directDist; // במקרה של תקלה נחזיר את המרחק הישיר
    }
    return directDist;
}

// פונקציה שעוברת על כל המטוסים ומחפשת את המטוס המאיים ביותר
function calculateThreat(threatLat, threatLon, radiusKm, threatSpeedKmH, planes, defenseZone) {
    let nearestPlane = null;
    let minDistanceKm = Infinity;

    // לולאה שעוברת על כל מטוס שהגיע מה-API
    for (let i = 0; i < planes.length; i++) {
        const state = planes[i];
        const pLon = state[5]; // קו אורך
        const pLat = state[6]; // קו רוחב
        const pVelocityMS = state[9]; // מהירות במטרים לשנייה
        const pHeading = state[10];   // כיוון טיסה במעלות

        if (!pLat || !pLon || pHeading === null) {
            continue;
        }

        const p1 = { latitude: threatLat, longitude: threatLon };
        const p2 = { latitude: pLat, longitude: pLon };
        const zoneCenter = { latitude: defenseZone.lat, longitude: defenseZone.lon };

        // חישוב המרחק  הכולל
        const safeDistance = calculatePathAvoidingZone(p1, p2, zoneCenter, defenseZone.radius);

        // בדיקה אם המטוס נמצא בתוך רדיוס החיפוש והוא הכי קרוב שמצאנו עד כה
        if (safeDistance <= radiusKm && safeDistance < minDistanceKm) {
            minDistanceKm = safeDistance;

            // חישוב וקטורי של זמן סגירה:
            // אנו בודקים את ההיטל של מהירות המטוס על הקו שמחבר אותו לנקודות ציון
            const bearingToThreat = getGreatCircleBearing(p2, p1);
            const angleDiff = pHeading - bearingToThreat;
            const angleRad = (angleDiff * Math.PI) / 180; // המרה מרדיאנים למעלות
            
            const planeSpeedKmH = pVelocityMS * 3.6; // המרה מקמ"ש
            const planeClosingComponent = planeSpeedKmH * Math.cos(angleRad);
            
            // מהירות הסגירה הכוללת היא מהירות הנכס + היטל מהירות המטוס לעברנו
            const relativeClosingSpeed = threatSpeedKmH + planeClosingComponent;
            
            let vectorTime = null;
            if (relativeClosingSpeed > 0) {
                // זמן = מרחק חלקי מהירות
                vectorTime = safeDistance / relativeClosingSpeed;
            }

            // שמירת פרטי המטוס שנמצא
            nearestPlane = {
                id: state[1] ? state[1].trim() : state[0],
                distance: safeDistance,
                country: state[2],
                altitude: state[7],
                velocity: planeSpeedKmH,
                heading: pHeading,
                vectorClosureTime: vectorTime
            };
        }
    }
    
    return { 
        nearestPlane: nearestPlane, 
        closureTime: nearestPlane ? nearestPlane.vectorClosureTime : null 
    };
}


// נתיב לחישוב איום - מקבל קואורדינטות ומחזיר את המטוס המאיים
app.post('/api/calculate-threat', async function(req, res) {
    try {
        const lat = req.body.latitude;
        const lon = req.body.longitude;
        const rad = req.body.radius;
        const spd = req.body.speed;
        
        const defLat = req.body.defenseLat;
        const defLon = req.body.defenseLon;
        const defRad = req.body.defenseRadius;

        // מביאים את נתוני המטוסים העדכניים
        const planesRaw = await fetchFlightData();
        
        const result = calculateThreat(
            parseFloat(lat),
            parseFloat(lon),
            parseFloat(rad),
            parseFloat(spd),
            planesRaw,
            { 
                lat: parseFloat(defLat || 0), 
                lon: parseFloat(defLon || 0), 
                radius: parseFloat(defRad || 0) 
            }
        );

        // החזרת התשובה ללקוח
        res.json({
            noThreat: result.nearestPlane === null,
            nearestPlane: result.nearestPlane,
            closureTime: result.closureTime
        });
    } catch (error) {
        console.log("קרתה שגיאה בחישוב:", error);
        res.status(500).json({ error: "Calculation failed" });
    }
});

// נתיב לשמירת מבצע שבוצע בתוך מסד הנתונים
app.post('/api/save-operation', async function(req, res) {
    try {
        const threatData = req.body.threat;
        const planeData = req.body.plane;
        const timeData = req.body.closureTime;

        // שימוש ב-Prisma כדי ליצור שורה חדשה בטבלה
        const savedOp = await prisma.operation.create({
            data: { 
                threat: threatData, 
                plane: planeData, 
                closureTime: parseFloat(timeData) 
            }
        });
        res.status(201).json(savedOp);
    } catch (error) {
        res.status(500).json({ error: "Failed to save" });
    }
});

//נתיב  לשליפת כל המבצעים ששמרנו ם
app.get('/api/saved-operations', async function(req, res) {
    try {
        const history = await prisma.operation.findMany({ 
            orderBy: { 
                createdAt: 'desc' 
            } 
        });
        res.json(history);
    } catch (error) {
        res.status(500).json({ error: "Failed to fetch history" });
    }
});

// נתיב למחיקת מבצע לפי ה-ID שלו
app.delete('/api/delete-operation/:id', async function(req, res) {
    try {
        const operationId = req.params.id; 
        await prisma.operation.delete({ 
            where: { 
                id: parseInt(operationId) 
            } 
        });
        res.status(200).json({ message: "Deleted" });
    } catch (error) {
        res.status(500).json({ error: "Delete failed" });
    }
});

app.listen(PORT, function() {
    console.log("🚀 Server is running on port " + PORT);
});