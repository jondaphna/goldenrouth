import React from 'react';

function ImportModal({ savedOps, onSelect, onDelete, onClose }) {
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <h2>ייבוא מבצע שמור</h2>
        
        {savedOps.length === 0 ? (
          <p>אין מבצעים שמורים להצגה.</p>
        ) : (
          <ul className="saved-list" style={{ listStyle: 'none', padding: 0 }}>
            {savedOps.map((op) => {
              // חילוץ נתונים לתוך משתנים נוחים
              const lat = op.threat.latitude?.toFixed(3);
              const lon = op.threat.longitude?.toFixed(3);
              const radius = op.threat.radius;
              const planeId = op.plane?.id || "ללא איום";
              const dateStr = new Date(op.createdAt).toLocaleString();

              return (
                <li key={op.id} className="op-item" style={{ borderBottom: '1px solid #ccc', padding: '15px 0', textAlign: 'right' }}>
                  {/* שורה 1: תאריך */}
                  <div style={{ fontWeight: 'bold' }}>📅 מבצע מ- {dateStr}</div>
                  
                  {/* שורה 2: נתוני נ"צ ורדיוס */}
                  <div style={{ fontSize: '0.9em' }}>
                    איום בנ"צ ({lat}, {lon}), רדיוס {radius} ק"מ – 
                  </div>

                  {/* שורה 3: פרטי האיום */}
                  <div style={{ fontSize: '0.9em', color: op.plane ? 'red' : 'green' }}>
                    {op.plane ? `⚠️ מטוס מאוים: ${planeId}, זמן סגירה ${op.closureTime?.toFixed(2)} שעות` : "✅ לא היה איום"}
                  </div>

                  {/* שורה 4: כפתורי פעולה */}
                  <div style={{ marginTop: '10px' }}>
                    <button onClick={() => onSelect(op)} style={{ marginLeft: '10px', cursor: 'pointer' }}>ייבא</button>
                    <button 
                      onClick={() => onDelete(op.id)} 
                      style={{ color: 'red', cursor: 'pointer', border: '1px solid red', background: 'none', borderRadius: '4px', padding: '2px 5px' }}
                    >
                      🗑️ מחק
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
        
        <button className="close-btn" onClick={onClose} style={{ marginTop: '20px', cursor: 'pointer' }}>סגור</button>
      </div>
    </div>
  );
}

export default ImportModal;