import React from 'react';

function InputForm(props) {
  const {
    latitude, setLatitude,
    longitude, setLongitude,
    speed, setSpeed,
    radius, setRadius
  } = props;


  const onLatChange = (e) => {
    const val = e.target.value;
    const num = parseFloat(val);
    // אם השדה ריק או שהמספר בטווח שבין 90- ל-90, רק אז נעדכן
    if (val === "" || (num >= -90 && num <= 90)) {
      setLatitude(val);
    }
  };

  const onLonChange = (e) => {
    const val = e.target.value;
    const num = parseFloat(val);
    // אם השדה ריק או שהמספר בטווח שבין 180- ל-180, רק אז נעדכן
    if (val === "" || (num >= -180 && num <= 180)) {
      setLongitude(val);
    }
  };

  const onPositiveChange = (val, setter) => {
    // מונע הכנסת מספרים שליליים למהירות ורדיוס
    if (val === "" || parseFloat(val) >= 0) {
      setter(val);
    }
  };

  return (
    <div className="input-form">
      {/* שורה 1: קואורדינטות */}
      <div className="form-row">
        <label>
          Latitude (קו רוחב):
          <input 
            type="number" 
            step="any"
            value={latitude} 
            onChange={onLatChange} // משתמש בפונקציה ההגנה
            placeholder="-90 עד 90" 
          />
        </label>
        <label>
          Longitude (קו אורך):
          <input 
            type="number" 
            step="any" 
            value={longitude} 
            onChange={onLonChange} // משתמש בפונקציה ההגנה
            placeholder="-180 עד 180" 
          />
        </label>
      </div>

      {/* שורה 2: מהירות ורדיוס */}
      <div className="form-row">
        <label>
          מהירות טיסה (קמ"ש):
          <input 
            type="number" 
            step="any" 
            value={speed} 
            onChange={(e) => onPositiveChange(e.target.value, setSpeed)} 
            placeholder="מהירות חיובית" 
          />
        </label>
        <label>
          רדיוס טיסה מרבי (ק"מ):
          <input 
            type="number" 
            step="any" 
            value={radius} 
            onChange={(e) => onPositiveChange(e.target.value, setRadius)} 
            placeholder="רדיוס חיובי" 
          />
        </label>
      </div>
    </div>
  );
}

export default InputForm;