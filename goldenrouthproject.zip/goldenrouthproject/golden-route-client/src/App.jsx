import { useEffect, useState } from "react";
import InputForm from "./InputForm";
import Results from "./Results";
import ImportModal from "./ImportModal";
function App() {
  
  const [latitude, setLatitude] = useState("");
  const [longitude, setLongitude] = useState("");
  const [speed, setSpeed] = useState("");
  const [radius, setRadius] = useState("");
  
  // נתוני מערכת ההגנה - שומר את נקודת האמצע והרדיוס של המעגל
  const [defensePoint, setDefensePoint] = useState({ lat: "32.0", lon: "34.8", radius: "10" });
  
  const [error, setError] = useState("");
  const [nearestPlane, setNearestPlane] = useState(null);
  const [closureTime, setClosureTime] = useState(null);
  const [noThreat, setNoThreat] = useState(false);
  const [calculated, setCalculated] = useState(false);
  
  // משתנים לניהול רשימת המבצעים השמורים 
  const [showModal, setShowModal] = useState(false);
  const [savedOps, setSavedOps] = useState([]);



  // פונקציה שלוקחת מבצע מהרשימה השמורה ומחזירה את כל הנתונים שלו למסך
  function handleSelectOperation(op) {
    // הפיכת הנתונים למחרוזות כדי שיוצגו בתיבות הטקסט 
    setLatitude(String(op.threat.latitude));
    setLongitude(String(op.threat.longitude));
    setRadius(String(op.threat.radius));
    setSpeed(String(op.threat.speed));

    setNearestPlane(op.plane); 
    setClosureTime(op.closureTime);
    
    setNoThreat(false); 
    setCalculated(true); 
    setError("");
    setShowModal(false); 
  }

  // פונקציה  לסגירת החלונית 
  function closeModal() {
    setShowModal(false);
  }

  // פונקציה שפונה לשרת כדי להביא את רשימת המבצעים הישנים ששמרנו ב-DB
  async function openModal() {
    try {
      const res = await fetch("http://localhost:4000/api/saved-operations");
      if (!res.ok) {
        throw new Error("Failed to fetch");
      }
      const data = await res.json();
      setSavedOps(data); // שמירת הרשימה בזיכרון
      setShowModal(true); 
    } catch (err) {
      console.error("Error:", err);
      alert("לא ניתן לטעון נתונים שמורים - וודא שהשרת פועל");
    }
  }

  // פונקציה ששולחת את האיום הנוכחי לשרת כדי שיישמר במסד הנתונים 
  async function handleSave() {
    if (!nearestPlane || noThreat) return;

    // בניית האובייקט לשליחה 
    const bodyData = {
      threat: {
        latitude: parseFloat(latitude),
        longitude: parseFloat(longitude),
        radius: parseFloat(radius),
        speed: parseFloat(speed),
      },
      plane: nearestPlane, 
      closureTime: closureTime 
    };

    try {
      const res = await fetch("http://localhost:4000/api/save-operation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(bodyData),
      });

      if (res.ok) {
        alert("🚀 המבצע נשמר בהצלחה ב-Database!");
      } else {
        throw new Error("שמירה נכשלה");
      }
    } catch (err) {
      console.error("Save error:", err);
      alert("שגיאה: לא ניתן לשמור את המבצע.");
    }
  }

  // פונקציה למחיקת מבצע ספציפי מה-Database לפי ה-ID שלו
  async function handleDeleteOperation(id) {
    const check = window.confirm("האם אתה בטוח שברצונך למחוק מבצע זה מההיסטוריה?");
    if (!check) return;

    try {
      const res = await fetch("http://localhost:4000/api/delete-operation/" + id, { 
        method: "DELETE" 
      });

      if (res.ok) {
        // מעדכן את הרשימה במסך ע"י הוצאת האיבר שמחקנו
        const filtered = savedOps.filter(function(op) {
          return op.id !== id;
        });
        setSavedOps(filtered);
        alert("המבצע נמחק.");
      }
    } catch (err) {
      alert("המחיקה נכשלה");
    }
  }
  


  useEffect(function() {

    if (!latitude || !longitude || !radius || !speed) return;

    // המרה למספרים ובדיקה שהם תקינים
    const latNum = parseFloat(latitude);
    const lonNum = parseFloat(longitude);
    const radNum = parseFloat(radius);
    const speedNum = parseFloat(speed);

    // שלא יוכלו לשים אותיות ורק מספרים
    if (isNaN(latNum) || isNaN(lonNum) || isNaN(radNum) || isNaN(speedNum)) {
      setError("אנא הזינו מספרים תקינים.");
      return;
    }

    // פונקציה פנימית ששולחת את כל הנתונים לסרבר לביצוע המתמטיקה
    async function calculateThreat() {
      try {
        const sendObj = {
          latitude: latNum,
          longitude: lonNum,
          radius: radNum,
          speed: speedNum,
          //למערכת ההגנה
          defenseLat: parseFloat(defensePoint.lat) || 0,
          defenseLon: parseFloat(defensePoint.lon) || 0,
          defenseRadius: parseFloat(defensePoint.radius) || 0
        };

        const res = await fetch("http://localhost:4000/api/calculate-threat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(sendObj),
        });

        if (res.ok) {
          const data = await res.json();
          // עדכון התוצאות מהשרת לתוך הזיכרון  
          setNearestPlane(data.nearestPlane);
          setClosureTime(data.closureTime);
          setNoThreat(data.noThreat);
          setCalculated(true);
          setError("");
        }
      } catch (err) {
        console.error("Fetch error:", err);
        setError("שגיאה בחישוב - וודא שהשרת פועל.");
      }
    }

    calculateThreat();
  }, [latitude, longitude, radius, speed, defensePoint]); 

  return (
    <div className="App" style={{ padding: "20px", fontFamily: "Arial", direction: "rtl" }}>
      <h1>נתיב הזהב – זיהוי איום</h1>
      
      <button onClick={openModal} style={{ marginBottom: "20px", cursor: "pointer" }}>
        📂 ייבא מבצע שמור
      </button>

      <InputForm
        latitude={latitude} setLatitude={setLatitude}
        longitude={longitude} setLongitude={setLongitude}
        speed={speed} setSpeed={setSpeed}
        radius={radius} setRadius={setRadius}
      />


      <div style={{ marginTop: "20px", padding: "15px", border: "2px solid #007bff", borderRadius: "10px", backgroundColor: "#f0f7ff", textAlign: "right" }}>
        <h3 style={{ color: "#007bff", marginTop: 0 }}>🛡️ הגדרות מערכת הגנה (בונוס) </h3>
        <p style={{ fontSize: "0.9em", color: "#555" }}>הזן את נתוני המכשול שהכטמ"ם צריך לעקוף בדרכו:</p>
        
        <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
          <div>
            <label style={{ display: "block" }}>קו רוחב (Lat):</label>
            <input 
              type="number" 
              value={defensePoint.lat} 
              // עדכון  של אובייקט defensePoint תוך שמירה על הערכים האחרים
              onChange={function(e) {
                const val = e.target.value;
                const num = parseFloat(val);
                if (val === "" || (num >= -90 && num <= 90)) {
                  setDefensePoint({...defensePoint, lat: val});
                }
              }} 
            />
          </div>

          <div>
            <label style={{ display: "block" }}>קו אורך (Lon):</label>
            <input 
              type="number" 
              value={defensePoint.lon} 
              onChange={function(e) {
                const val = e.target.value;
                const num = parseFloat(val);
                if (val === "" || (num >= -180 && num <= 180)) {
                  setDefensePoint({...defensePoint, lon: val});
                }
              }} 
            />
          </div>

          <div>
            <label style={{ display: "block" }}>רדיוס הגנה (ק"מ):</label>
            <input 
              type="number" 
              value={defensePoint.radius} 
              onChange={function(e) {
                const val = e.target.value;
                if (val === "" || parseFloat(val) >= 0) {
                  setDefensePoint({...defensePoint, radius: val});
                }
              }} 
            />
          </div>
        </div>
      </div>

      <hr style={{ margin: "30px 0" }} />

      {/* הצגת תוצאות החישוב */}
      <Results
        nearestPlane={nearestPlane}
        closureTime={closureTime}
        noThreat={noThreat}
        error={error}
        calculated={calculated}
        onSave={handleSave}
      />

      {/* חלונית  המבצעים - מופיעה רק כשיש פקודה להציג אותה */}
      {showModal && (
        <ImportModal
          savedOps={savedOps}
          onSelect={handleSelectOperation}
          onDelete={handleDeleteOperation}
          onClose={closeModal}
        />
      )}
    </div>
  );
}

export default App;